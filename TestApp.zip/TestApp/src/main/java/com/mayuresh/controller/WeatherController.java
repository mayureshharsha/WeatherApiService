package com.mayuresh.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.mayuresh.model.City;
import com.mayuresh.service.WeatherService;

@RestController
public class WeatherController {

	@Autowired
	private WeatherService weatherservice; 
	 
	//TO GET ALL DATA
	@RequestMapping(value="/alldata", method = RequestMethod.GET)
	public List<City> getAllData()
	{
		
		return weatherservice.getAllData();
	}
	
	//TO GET SPECIFIC CITY DATA
	@RequestMapping(value="/city/{cityName}", method = RequestMethod.GET)
	public @ResponseBody City getDpecificCityDetails(@PathVariable String cityName){
		return weatherservice.getSpecificData(cityName);
		
	}
	
	
	//TO ADD DATA FROM POSTMAN USING POST
	@RequestMapping(value="/city", method = RequestMethod.POST,consumes= "application/json")
	public @ResponseBody void addCity(@RequestBody City city){
		weatherservice.addCity(city);
		
	}
	
	//TO UPDATE DATA
	@RequestMapping(value="/city/{cityName}", method = RequestMethod.PUT)
	public @ResponseBody String updateCity(@PathVariable String cityName,@RequestBody City city){
		weatherservice.updateCity(cityName,city);
		return "OK";
		
	}
	
		//TO DELETE DATA
		@RequestMapping(value="/city/{cityName}", method = RequestMethod.DELETE)
		public @ResponseBody String deleteCity(@PathVariable String cityName){
			weatherservice.deleteCity(cityName);
			return "OK";
			
		}
	
	
	
}
