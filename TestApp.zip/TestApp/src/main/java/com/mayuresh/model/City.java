package com.mayuresh.model;

import java.util.Date;
import java.util.List;

public class City {
	
	
	private  String cityName;
	
	private Date date;
	
    private List<TemperatureDetails> temp;
    
	public String getCityName() {
		return cityName;
	}
	public void setCityName(String cityName) {
		this.cityName = cityName;
	}
	public Date getDate() {
		return date;
	}
	public void setDate(Date date) {
		
		this.date = date;
	}
	
	public List<TemperatureDetails> getTemp() {
		return temp;
	}
	public void setTemp(List<TemperatureDetails> temp) {
		this.temp = temp;
	}
	public City() 
	{
		
	}
	public City(String cityName, Date date, List<TemperatureDetails> temp) {
		super();
		this.cityName = cityName;
		this.date = date;
		this.temp = temp;
	}
	

	

}
