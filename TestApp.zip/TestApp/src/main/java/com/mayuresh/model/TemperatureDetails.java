package com.mayuresh.model;


public class TemperatureDetails {

	
	private String time;
	private String temperature;
	
	public String getTime() {
		return time;
	}
	
	public void setTime(String time) {
		this.time = time;
	}
	public String getTemperature() {
		return temperature;
	}
	public void setTemperature(String temperature) {
		this.temperature = temperature;
	}
	public TemperatureDetails(String time, String temperature) {
		super();
		this.time = time;
		this.temperature = temperature;
	}
	
	public TemperatureDetails() {
		
	}
	
	
}
