package com.mayuresh.service;


import java.util.ArrayList;
import java.util.List;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.mayuresh.model.City;


@Service
public class WeatherService {
	private static final Logger log =  LoggerFactory.getLogger(WeatherService.class);
	
	private List<City> list= new ArrayList<City>();

	

	

	public void addCity(City city) {
		
		if(list.size()==0)
			list.add(city);
		// FOR DUPLICATE ROWS
		else
		{
			for (int i = 0; i < list.size(); i++) {	
				City c=list.get(i);
				if(city != null && city.getCityName() != null && !c.getCityName().equalsIgnoreCase(city.getCityName())){
					list.add(city);
					return;
				}
			}
		}
	
	}


	public void updateCity(String cityName, City city) {
		for (int i = 0; i < list.size(); i++) {	
			City c=list.get(i);
			if(c != null && c.getCityName() != null && c.getCityName().equalsIgnoreCase(cityName)){
				list.set(i, city);
				return;
			}
		}
	}


	public void deleteCity(String cityName) {
		log.debug("====List SIZE==" + list.size());
		for (int i = 0; i < list.size(); i++) {
			City c = list.get(i);
			log.debug("====FOUND CITY==" + c.getCityName());
			if(c != null && c.getCityName() != null && c.getCityName().trim().equals(cityName.trim())){
				list.remove(i);
				return;
			}
		}
	}


	public List<City> getAllData() {
		// TODO Auto-generated method stub
		return list;
	}
	
	public City getSpecificData(String cityname) {
		for (City city : list) {
			if(city.getCityName().equals(cityname))
				return city;
		}
		return null;
	}
}




